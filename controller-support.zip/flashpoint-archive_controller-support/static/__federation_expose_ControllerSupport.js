"use strict";
(globalThis["webpackChunkcontroller_support"] = globalThis["webpackChunkcontroller_support"] || []).push([["272"], {
828: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ControllerSupport),
  selectGameField: () => (/* binding */ selectGameField)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(893);
// EXTERNAL MODULE: ./node_modules/react/compiler-runtime.js
var compiler_runtime = __webpack_require__(827);
// EXTERNAL MODULE: ./node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(436);
// EXTERNAL MODULE: external "flashpoint-launcher-renderer-ext/hooks"
var hooks_ = __webpack_require__(698);
// EXTERNAL MODULE: consume shared module (default) react@19.1.0 (strict) (fallback: G:\Data\Projects\Extensions\core-controller\node_modules\react\index.js)
var consume_shared_module_default_react_19_1_strict_fallback_G_Data_Projects_Extensions_core_controller_node_modules_react_index_js_ = __webpack_require__(697);
;// CONCATENATED MODULE: ./src/shared.ts
function getFormattedMappedName({ code, mode }, name) {
    const mappedName = getMappedName({
        code,
        mode
    }, name);
    if (mappedName.name !== undefined) {
        return `${mappedName.name} - (${mappedName.output})`;
    } else {
        return mappedName.output;
    }
}
function getMappedName({ code, mode }, name) {
    // We can map all regular letters to ascii chars
    if (mode === 'keyboard' && code >= 65 && code <= 90) {
        return {
            output: String.fromCharCode(code),
            name
        };
    }
    if (mode in readableOutputs) {
        const category = readableOutputs[mode];
        if (code in category) {
            return {
                output: category[code],
                name
            };
        }
    }
    return {
        output: `Unknown (${mode} - ${code})`,
        name
    };
}
const readableInputs = (/* unused pure expression or super */ null && ({
    stick: {
        1: 'Left Stick',
        2: 'Right Stick'
    },
    stickbutton: {
        1: 'Up',
        3: 'Right',
        5: 'Down',
        7: 'Left'
    },
    trigger: {
        5: 'Left Trigger',
        6: 'Right Trigger'
    },
    triggerbutton: {
        2: 'Trigger Pull'
    },
    dpadbutton: {
        1: 'Up',
        2: 'Right',
        4: 'Down',
        8: 'Left'
    },
    button: {
        1: 'A',
        2: 'B',
        3: 'X',
        4: 'Y',
        5: 'Select',
        7: 'Start'
    }
}));
const readableOutputs = {
    mousemovement: {
        1: 'Mouse Up',
        2: 'Mouse Down',
        3: 'Mouse Left',
        4: 'Mouse Right'
    },
    mousebutton: {
        1: 'Left Mouse Button',
        3: 'Right Mouse Button'
    },
    keyboard: {
        16777216: 'Escape',
        16777220: 'Enter',
        16777234: 'Arrow Left',
        16777235: 'Arrow Up',
        16777236: 'Arrow Right',
        16777237: 'Arrow Down'
    }
};

;// CONCATENATED MODULE: ./src/components/ControllerSupport.tsx






function isGame(content) {
    return content !== undefined && 'legacyApplicationPath' in content;
}
const selectGameField = (viewId, key)=>(0,reselect/* createSelector */.P1)([
        (state)=>state.search.views[viewId].isEditing,
        (state)=>isGame(state.search.views[viewId].selectedGame) ? state.search.views[viewId].selectedGame[key] : undefined,
        (state)=>isGame(state.search.views[viewId].editingGame) ? state.search.views[viewId].editingGame[key] : undefined
    ], (isEditing, selectedGameValue, editingGameValue)=>isEditing ? editingGameValue : selectedGameValue);
function ControllerSupport(props) {
    const $ = (0,compiler_runtime.c)(29);
    let t0;
    if ($[0] !== props.viewId) {
        t0 = selectGameField(props.viewId, "extData");
        $[0] = props.viewId;
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const extData = (0,hooks_.useAppSelector)(t0);
    const controllerConfig = extData?.controller?.config;
    let t1;
    bb0: {
        if (!controllerConfig) {
            let t2;
            if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
                t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {});
                $[2] = t2;
            } else {
                t2 = $[2];
            }
            t1 = t2;
            break bb0;
        }
        let list;
        if ($[3] !== controllerConfig.button || $[4] !== controllerConfig.dpad || $[5] !== controllerConfig.stick || $[6] !== controllerConfig.trigger) {
            list = [];
            let isDpadSameAsLeftStick = false;
            const leftStick = controllerConfig.stick ? controllerConfig.stick.find(_temp) : undefined;
            const rightStick = controllerConfig.stick ? controllerConfig.stick.find(_temp2) : undefined;
            if (controllerConfig.dpad && leftStick) {
                let allMatch = true;
                for (const button of controllerConfig.dpad.dpadbutton){
                    const stickButton = leftStick.stickbutton.find((s_1)=>s_1.name === button.name);
                    if (stickButton) {
                        if (stickButton.slots.slot.code !== button.slots.slot.code || stickButton.slots.slot.mode !== button.slots.slot.mode) {
                            allMatch = false;
                        }
                    } else {
                        allMatch = false;
                    }
                }
                isDpadSameAsLeftStick = allMatch;
            }
            if (controllerConfig.dpad) {
                const t2 = isDpadSameAsLeftStick ? "Dpad / Left Stick" : "Dpad";
                let t3;
                if ($[8] !== t2) {
                    t3 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subheader",
                        children: t2
                    }, "dpad-header");
                    $[8] = t2;
                    $[9] = t3;
                } else {
                    t3 = $[9];
                }
                list.push(t3);
                let inner;
                if ($[10] !== controllerConfig.dpad.dpadbutton) {
                    inner = [];
                    for (const button_0 of controllerConfig.dpad.dpadbutton){
                        inner.push(/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "controller-config-button--input",
                                    children: [
                                        button_0.name,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: getFormattedMappedName(button_0.slots.slot, button_0.actionName)
                                })
                            ]
                        }, button_0.name));
                    }
                    $[10] = controllerConfig.dpad.dpadbutton;
                    $[11] = inner;
                } else {
                    inner = $[11];
                }
                let t4;
                if ($[12] !== inner) {
                    t4 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subsection",
                        children: inner
                    }, "dpad-subsection");
                    $[12] = inner;
                    $[13] = t4;
                } else {
                    t4 = $[13];
                }
                list.push(t4);
            }
            if (controllerConfig.button) {
                let t2;
                if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
                    t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subheader",
                        children: "Buttons"
                    }, "buttons-header");
                    $[14] = t2;
                } else {
                    t2 = $[14];
                }
                list.push(t2);
                let inner_0;
                if ($[15] !== controllerConfig.button) {
                    inner_0 = [];
                    for (const button_1 of controllerConfig.button){
                        inner_0.push(/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "controller-config-button--input",
                                    children: [
                                        button_1.name,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: getFormattedMappedName(button_1.slots.slot, button_1.actionName)
                                })
                            ]
                        }, button_1.name));
                    }
                    $[15] = controllerConfig.button;
                    $[16] = inner_0;
                } else {
                    inner_0 = $[16];
                }
                let t3;
                if ($[17] !== inner_0) {
                    t3 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subsection",
                        children: inner_0
                    }, "buttons-subsection");
                    $[17] = inner_0;
                    $[18] = t3;
                } else {
                    t3 = $[18];
                }
                list.push(t3);
            }
            if (!isDpadSameAsLeftStick && leftStick) {
                let isMouseMovement = true;
                for (const button_2 of leftStick.stickbutton){
                    if (button_2.slots.slot.mode !== "mousemovement") {
                        isMouseMovement = false;
                        break;
                    }
                }
                list.push(/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "controller-config-subheader",
                    children: leftStick.name
                }, "left-stick-header"));
                const inner_1 = [];
                if (isMouseMovement) {
                    let t2;
                    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
                        t2 = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--input",
                                    children: "All Directions:"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: "Mouse Movement"
                                })
                            ]
                        });
                        $[19] = t2;
                    } else {
                        t2 = $[19];
                    }
                    inner_1.push(t2);
                } else {
                    for (const button_3 of leftStick.stickbutton){
                        inner_1.push(/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "controller-config-button--input",
                                    children: [
                                        button_3.name,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: getFormattedMappedName(button_3.slots.slot, button_3.actionName)
                                })
                            ]
                        }, button_3.uq_index));
                    }
                }
                let t2;
                if ($[20] !== inner_1) {
                    t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subsection",
                        children: inner_1
                    });
                    $[20] = inner_1;
                    $[21] = t2;
                } else {
                    t2 = $[21];
                }
                list.push(t2);
            }
            if (rightStick) {
                let isMouseMovement_0 = true;
                for (const button_4 of rightStick.stickbutton){
                    if (button_4.slots.slot.mode !== "mousemovement") {
                        isMouseMovement_0 = false;
                        break;
                    }
                }
                list.push(/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "controller-config-subheader",
                    children: rightStick.name
                }));
                const inner_2 = [];
                if (isMouseMovement_0) {
                    let t2;
                    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
                        t2 = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--input",
                                    children: "All Directions:"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: "Mouse Movement"
                                })
                            ]
                        });
                        $[22] = t2;
                    } else {
                        t2 = $[22];
                    }
                    inner_2.push(t2);
                } else {
                    for (const button_5 of rightStick.stickbutton){
                        inner_2.push(/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "controller-config-button--input",
                                    children: [
                                        button_5.name,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: getFormattedMappedName(button_5.slots.slot, button_5.actionName)
                                })
                            ]
                        }, button_5.uq_index));
                    }
                }
                let t2;
                if ($[23] !== inner_2) {
                    t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subsection",
                        children: inner_2
                    });
                    $[23] = inner_2;
                    $[24] = t2;
                } else {
                    t2 = $[24];
                }
                list.push(t2);
            }
            if (controllerConfig.trigger) {
                for (const trigger of controllerConfig.trigger){
                    list.push(/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subheader",
                        children: trigger.name
                    }));
                    list.push(/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-subsection",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "controller-config-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "controller-config-button--input",
                                    children: [
                                        trigger.triggerbutton.name,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "controller-config-button--output",
                                    children: getFormattedMappedName(trigger.triggerbutton.slots.slot, trigger.triggerbutton.actionName)
                                })
                            ]
                        }, trigger.uq_index)
                    }));
                }
            }
            $[3] = controllerConfig.button;
            $[4] = controllerConfig.dpad;
            $[5] = controllerConfig.stick;
            $[6] = controllerConfig.trigger;
            $[7] = list;
        } else {
            list = $[7];
        }
        t1 = list;
    }
    const mappedTable = t1;
    if (controllerConfig) {
        let t2;
        if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                children: "Controller Configuration: "
            });
            $[25] = t2;
        } else {
            t2 = $[25];
        }
        let t3;
        if ($[26] !== mappedTable) {
            t3 = /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "browse-right-sidebar__row",
                children: [
                    t2,
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "controller-config-inner",
                        children: mappedTable
                    })
                ]
            });
            $[26] = mappedTable;
            $[27] = t3;
        } else {
            t3 = $[27];
        }
        return t3;
    } else {
        let t2;
        if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
            t2 = /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {});
            $[28] = t2;
        } else {
            t2 = $[28];
        }
        return t2;
    }
}
function _temp2(s_0) {
    return s_0.name === "Right Stick";
}
function _temp(s) {
    return s.name === "Left Stick";
}


}),

}]);