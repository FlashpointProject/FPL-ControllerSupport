"use strict";
(globalThis["webpackChunkcontroller_support"] = globalThis["webpackChunkcontroller_support"] || []).push([["506"], {
392: (function (__unused_webpack_module, exports, __webpack_require__) {
/**
 * @license React
 * react-compiler-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */


var ReactSharedInternals =
  (__webpack_require__(697)/* .__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE */.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE);
exports.c = function (size) {
  return ReactSharedInternals.H.useMemoCache(size);
};


}),
631: (function (__unused_webpack_module, exports) {
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */


var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
  REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
function jsxProd(type, config, maybeKey) {
  var key = null;
  void 0 !== maybeKey && (key = "" + maybeKey);
  void 0 !== config.key && (key = "" + config.key);
  if ("key" in config) {
    maybeKey = {};
    for (var propName in config)
      "key" !== propName && (maybeKey[propName] = config[propName]);
  } else maybeKey = config;
  config = maybeKey.ref;
  return {
    $$typeof: REACT_ELEMENT_TYPE,
    type: type,
    key: key,
    ref: void 0 !== config ? config : null,
    props: maybeKey
  };
}
exports.Fragment = REACT_FRAGMENT_TYPE;
exports.jsx = jsxProd;
exports.jsxs = jsxProd;


}),
827: (function (module, __unused_webpack_exports, __webpack_require__) {
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  module.exports = __webpack_require__(392);
} else {}


}),
893: (function (module, __unused_webpack_exports, __webpack_require__) {


if (true) {
  module.exports = __webpack_require__(631);
} else {}


}),
229: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (Initializer)
});
/* ESM import */var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(893);
/* ESM import */var react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(827);
/* ESM import */var flashpoint_launcher_renderer_ext_actions_main__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(819);
/* ESM import */var flashpoint_launcher_renderer_ext_actions_main__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(flashpoint_launcher_renderer_ext_actions_main__WEBPACK_IMPORTED_MODULE_2__);
/* ESM import */var flashpoint_launcher_renderer_ext_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(698);
/* ESM import */var flashpoint_launcher_renderer_ext_hooks__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(flashpoint_launcher_renderer_ext_hooks__WEBPACK_IMPORTED_MODULE_3__);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(697);
/* ESM import */var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);





function Initializer() {
    const $ = (0,react_compiler_runtime__WEBPACK_IMPORTED_MODULE_1__.c)(4);
    const dispatch = (0,flashpoint_launcher_renderer_ext_hooks__WEBPACK_IMPORTED_MODULE_3__.useAppDispatch)();
    let t0;
    let t1;
    if ($[0] !== dispatch) {
        t0 = ()=>{
            dispatch((0,flashpoint_launcher_renderer_ext_actions_main__WEBPACK_IMPORTED_MODULE_2__.addGameSidebarComponent)({
                section: "bottom",
                name: "core_controller/ControllerSupport"
            }));
            return ()=>{
                dispatch((0,flashpoint_launcher_renderer_ext_actions_main__WEBPACK_IMPORTED_MODULE_2__.removeGameSidebarComponent)({
                    section: "bottom",
                    name: "core_controller/ControllerSupport"
                }));
            };
        };
        t1 = [
            dispatch
        ];
        $[0] = dispatch;
        $[1] = t0;
        $[2] = t1;
    } else {
        t0 = $[1];
        t1 = $[2];
    }
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(t0, t1);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}


}),

}]);